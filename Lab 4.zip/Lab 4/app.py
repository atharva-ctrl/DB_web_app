import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, abort

app = Flask(__name__)
DB_PATH = os.path.join(os.path.dirname(__file__), "movies_lab2.db")

def get_db():
    if not os.path.exists(DB_PATH):
        raise FileNotFoundError("Database file not found: " + DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():
    conn = get_db()
    movies = conn.execute(
        "SELECT m.movie_id, m.name, m.year, m.score, c.country_name, r.rating_value "
        "FROM movie m "
        "LEFT JOIN country c ON m.country_id = c.country_id "
        "LEFT JOIN rating r ON m.rating_id = r.rating_id "
        "ORDER BY m.movie_id DESC LIMIT 50"
    ).fetchall()
    conn.close()
    return render_template("index.html", movies=movies)

@app.route("/add", methods=["GET", "POST"])
def add():
    conn = get_db()
    error = None
    if request.method == "POST":
        name = request.form["name"].strip()
        if not name:
            error = "Name is required."
        else:
            conn.execute(
                "INSERT INTO movie (name, year, genre, score, company, country_id, rating_id) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (name, request.form["year"] or None, request.form["genre"] or None,
                 request.form["score"] or None, request.form["company"] or None,
                 request.form["country_id"], request.form["rating_id"]),
            )
            conn.commit()
            conn.close()
            return redirect(url_for("index"))
    countries = conn.execute("SELECT country_id, country_name FROM country ORDER BY country_name").fetchall()
    ratings = conn.execute("SELECT rating_id, rating_value FROM rating ORDER BY rating_value").fetchall()
    conn.close()
    return render_template("form.html", movie=None, countries=countries,
                           ratings=ratings, action="Add", error=error)

@app.route("/edit/<int:movie_id>", methods=["GET", "POST"])
def edit(movie_id):
    conn = get_db()
    movie = conn.execute("SELECT * FROM movie WHERE movie_id = ?", (movie_id,)).fetchone()
    if movie is None:
        conn.close()
        abort(404)
    error = None
    if request.method == "POST":
        name = request.form["name"].strip()
        if not name:
            error = "Name is required."
        else:
            conn.execute(
                "UPDATE movie SET name = ?, year = ?, genre = ?, score = ?, company = ?, "
                "country_id = ?, rating_id = ? WHERE movie_id = ?",
                (name, request.form["year"] or None, request.form["genre"] or None,
                 request.form["score"] or None, request.form["company"] or None,
                 request.form["country_id"], request.form["rating_id"], movie_id),
            )
            conn.commit()
            conn.close()
            return redirect(url_for("index"))
    countries = conn.execute("SELECT country_id, country_name FROM country ORDER BY country_name").fetchall()
    ratings = conn.execute("SELECT rating_id, rating_value FROM rating ORDER BY rating_value").fetchall()
    conn.close()
    return render_template("form.html", movie=movie, countries=countries,
                           ratings=ratings, action="Edit", error=error)
@app.route("/delete/<int:movie_id>", methods=["POST"])
def delete(movie_id):
    conn = get_db()
    conn.execute("DELETE FROM movie_person WHERE movie_id = ?", (movie_id,))
    cur = conn.execute("DELETE FROM movie WHERE movie_id = ?", (movie_id,))
    deleted = cur.rowcount
    conn.commit()
    conn.close()
    if deleted == 0:
        abort(404)
    return redirect(url_for("index"))
                               
if __name__ == "__main__":
    app.run(debug=True)