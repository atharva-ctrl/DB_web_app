-- Lab 4: Movie database for the Flask app
-- Part 1: create the five tables
-- Part 2: insert sample records for testing

-- Parent Tables (no foreign keys)
CREATE TABLE country (
    country_id INTEGER PRIMARY KEY AUTOINCREMENT,
    country_name TEXT NOT NULL UNIQUE
);

CREATE TABLE rating (
    rating_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rating_value TEXT NOT NULL UNIQUE
);

-- Core Entity
CREATE TABLE movie (
    movie_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    year INTEGER,
    released TEXT,
    runtime INTEGER,
    budget INTEGER,
    gross INTEGER,
    score REAL,
    votes INTEGER,
    company TEXT,
    genre TEXT,
    country_id INTEGER,
    rating_id INTEGER,
    FOREIGN KEY (country_id) REFERENCES country(country_id),
    FOREIGN KEY (rating_id) REFERENCES rating(rating_id)
);

-- Person Entity
CREATE TABLE person (
    person_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

-- Junction Table for M:N Relationship (Movie to Person)
CREATE TABLE movie_person (
    movie_id INTEGER NOT NULL,
    person_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    PRIMARY KEY (movie_id, person_id, role),
    FOREIGN KEY (movie_id) REFERENCES movie(movie_id),
    FOREIGN KEY (person_id) REFERENCES person(person_id)
);

-- Insert Countries
INSERT INTO country (country_name) VALUES ('USA');
INSERT INTO country (country_name) VALUES ('UK');
INSERT INTO country (country_name) VALUES ('Germany');

-- Insert Ratings
INSERT INTO rating (rating_value) VALUES ('PG-13');
INSERT INTO rating (rating_value) VALUES ('R');
INSERT INTO rating (rating_value) VALUES ('PG');

-- Insert Sample Movies
INSERT INTO movie (name, year, released, runtime, budget, gross, score, votes, company, genre, country_id, rating_id)
VALUES ('The Dark Knight Rises', 2012, '7/20/12', 164, 250000000, 448139099, 8.4, 1253772, 'Warner Bros.', 'Action', 2, 1);

INSERT INTO movie (name, year, released, runtime, budget, gross, score, votes, company, genre, country_id, rating_id)
VALUES ('Django Unchained', 2012, '12/25/12', 165, 100000000, 162805434, 8.4, 1070691, 'The Weinstein Company', 'Drama', 1, 2);

INSERT INTO movie (name, year, released, runtime, budget, gross, score, votes, company, genre, country_id, rating_id)
VALUES ('The Hunger Games', 2012, '3/23/12', 142, 78000000, 408010692, 7.2, 748581, 'Lionsgate', 'Adventure', 1, 1);

INSERT INTO movie (name, year, released, runtime, budget, gross, score, votes, company, genre, country_id, rating_id)
VALUES ('The Avengers', 2012, '5/4/12', 143, 220000000, 623357910, 8.1, 1064633, 'Marvel Studios', 'Action', 1, 1);

INSERT INTO movie (name, year, released, runtime, budget, gross, score, votes, company, genre, country_id, rating_id)
VALUES ('Prometheus', 2012, '6/8/12', 124, 130000000, 126477084, 7.0, 503113, 'Twentieth Century Fox Film Corporation', 'Adventure', 1, 2);

-- Insert Sample People
INSERT INTO person (name) VALUES ('Christopher Nolan');
INSERT INTO person (name) VALUES ('Quentin Tarantino');
INSERT INTO person (name) VALUES ('Gary Ross');
INSERT INTO person (name) VALUES ('Joss Whedon');
INSERT INTO person (name) VALUES ('Ridley Scott');
INSERT INTO person (name) VALUES ('Christian Bale');
INSERT INTO person (name) VALUES ('Jamie Foxx');
INSERT INTO person (name) VALUES ('Jennifer Lawrence');
INSERT INTO person (name) VALUES ('Robert Downey Jr.');
INSERT INTO person (name) VALUES ('Noomi Rapace');
INSERT INTO person (name) VALUES ('Jonathan Nolan');

-- Insert Movie-Person Relationships (roles)
INSERT INTO movie_person (movie_id, person_id, role) VALUES (1, 1, 'Director');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (1, 11, 'Writer');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (1, 6, 'Actor');

INSERT INTO movie_person (movie_id, person_id, role) VALUES (2, 2, 'Director');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (2, 2, 'Writer');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (2, 7, 'Actor');

INSERT INTO movie_person (movie_id, person_id, role) VALUES (3, 3, 'Director');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (3, 3, 'Writer');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (3, 8, 'Actor');

INSERT INTO movie_person (movie_id, person_id, role) VALUES (4, 4, 'Director');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (4, 4, 'Writer');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (4, 9, 'Actor');

INSERT INTO movie_person (movie_id, person_id, role) VALUES (5, 5, 'Director');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (5, 5, 'Writer');
INSERT INTO movie_person (movie_id, person_id, role) VALUES (5, 10, 'Actor');
